package com.example.android.quakereport;

public class Earthquake {
    private Double mMagnitude;
    private String mLocation;
    private long mTimeInMilliseconds;

    public Earthquake(Double magnitude,String Location , long timeinmilliseconds)
    {
        mMagnitude=magnitude;
        mLocation=Location;
        mTimeInMilliseconds=timeinmilliseconds;
    }



    public Double getmMagnitude() {
        return mMagnitude;
    }

    public String getmLocation() {
        return mLocation;
    }

    public long getmTimeInMilliseconds() {
        return mTimeInMilliseconds;
    }
}
