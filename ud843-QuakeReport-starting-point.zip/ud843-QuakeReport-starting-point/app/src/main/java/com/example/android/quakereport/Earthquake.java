package com.example.android.quakereport;

public class Earthquake {
    private String mMagnitude;
    private String mLocation;
    private String mDate;
    private long mTimeInMilliseconds;

    public Earthquake(String magnitude,String Location, String date , long timeinmilliseconds)
    {
        mMagnitude=magnitude;
        mLocation=Location;
        mDate=date;
        mTimeInMilliseconds=timeinmilliseconds;
    }

    public String getmMagnitude() {
        return mMagnitude;
    }

    public String getmLocation() {
        return mLocation;
    }

    public String getmDate() {
        return mDate;
    }

    public long getmTimeInMilliseconds() {
        return mTimeInMilliseconds;
    }
}
